let currentUser = null;
let xogadoresGrupo = [];
let grupoEditando = null;

document.addEventListener("DOMContentLoaded", () => {
    if (!currentUser) {
        showTab('login-container');
    } else {
        actualizarSeleccionGrupos();
        mostrarGrupos();
    }
});

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username && password) {
        currentUser = username;
        localStorage.setItem(`user_${username}`, JSON.stringify({username, password}));
        showTab('formulario');
        actualizarSeleccionGrupos();
        mostrarGrupos();
    } else {
        alert('Por favor, introduce o nome de usuario e contrasinal.');
    }
}

function showTab(tabName) {
    document.querySelectorAll('.tab-content, .login-container').forEach(tab => {
        tab.classList.remove('active');
    });
    document.getElementById(tabName).classList.add('active');
}

function promptPassword(action, param = null) {
    const password = prompt("Por favor, introduce o contrasinal:");
    const user = JSON.parse(localStorage.getItem(`user_${currentUser}`));
    if (user && user.password === password) {
        action(param);
    } else {
        alert("Contrasinal incorrecto.");
    }
}

function enviarWhatsAppGrupo() {
    const nomePartido = document.getElementById('nomePartidoGrupo').value;
    const data = document.getElementById('dataGrupo').value;

    if (!nomePartido || !data) {
        alert("Por favor, complete o nome do partido e a data.");
        return;
    }

    const mensaxe = `Ola equipo, aquí está a lista do terceiro tempo: Nome do Partido: ${nomePartido}, Data: ${data}`;
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(mensaxe)}`;
    window.open(url, '_blank');
}

function limparFormularioGrupo() {
    document.getElementById('nomePartidoGrupo').value = '';
    document.getElementById('dataGrupo').value = '';
    document.getElementById('seleccionarGrupo').value = '';
    document.getElementById('menuGrupo').value = '';
    document.getElementById('grupoSeleccionado').innerHTML = '<h2>Composición do Grupo</h2>';
}

function actualizarSeleccionGrupos() {
    const seleccionarGrupo = document.getElementById('seleccionarGrupo');
    seleccionarGrupo.innerHTML = '<option value="" selected disabled>Seleccionar Grupo</option>';
    const grupos = JSON.parse(localStorage.getItem(`grupos_${currentUser}`)) || [];
    grupos.forEach(grupo => {
        const option = document.createElement('option');
        option.value = grupo.nome;
        option.textContent = grupo.nome;
        seleccionarGrupo.appendChild(option);
    });
}

function mostrarGrupoSeleccionado() {
    const grupoSeleccionado = document.getElementById('seleccionarGrupo').value;
    const grupos = JSON.parse(localStorage.getItem(`grupos_${currentUser}`)) || [];
    const grupo = grupos.find(grupo => grupo.nome === grupoSeleccionado);
    const grupoDiv = document.getElementById('grupoSeleccionado');
    grupoDiv.innerHTML = '<h2>Composición do Grupo</h2>';
    grupo.xogadores.forEach(xogador => {
        const xogadorDiv = document.createElement('div');
        xogadorDiv.innerText = xogador;
        grupoDiv.appendChild(xogadorDiv);
    });
}

function mostrarGrupos() {
    const listaGrupos = document.getElementById('listaGrupos');
    listaGrupos.innerHTML = '';
    const grupos = JSON.parse(localStorage.getItem(`grupos_${currentUser}`)) || [];
    grupos.forEach((grupo, index) => {
        const grupoDiv = document.createElement('div');
        grupoDiv.classList.add('grupo');
        grupoDiv.innerHTML = `
            <h3>${grupo.nome}</h3>
            <button onclick="promptPassword(editarGrupo, ${index})">Editar</button>
            <button onclick="promptPassword(eliminarGrupo, ${index})">Eliminar</button>
            <div>
                <h4>Xogadores:</h4>
                <ul>
                    ${grupo.xogadores.map(xogador => `<li>${xogador}</li>`).join('')}
                </ul>
            </div>
        `;
        listaGrupos.appendChild(grupoDiv);
    });
}

function crearGrupo() {
    const nomeGrupo = document.getElementById('nomeGrupo').value;
    if (nomeGrupo && xogadoresGrupo.length > 0) {
        let grupos = JSON.parse(localStorage.getItem(`grupos_${currentUser}`)) || [];

        if (grupoEditando !== null) {
            grupos[grupoEditando] = { nome: nomeGrupo, xogadores: xogadoresGrupo };
            grupoEditando = null;
        } else {
            grupos.push({ nome: nomeGrupo, xogadores: xogadoresGrupo });
        }

        localStorage.setItem(`grupos_${currentUser}`, JSON.stringify(grupos));
        document.getElementById('nomeGrupo').value = '';
        xogadoresGrupo = [];
        mostrarXogadoresGrupo();
        mostrarGrupos();
        actualizarSeleccionGrupos(); // Actualizar a selección de grupos
    } else {
        alert("Por favor, introduza o nome do grupo e engada xogadores.");
    }
}

function engadirXogador() {
    const nomeXogador = document.getElementById('nomeXogador').value;
    if (nomeXogador) {
        xogadoresGrupo.push(nomeXogador);
        document.getElementById('nomeXogador').value = '';
        mostrarXogadoresGrupo();
    } else {
        alert("Por favor, introduza o nome do xogador.");
    }
}

function eliminarXogador(index) {
    xogadoresGrupo.splice(index, 1);
    mostrarXogadoresGrupo();
}

function editarGrupo(index) {
    const grupos = JSON.parse(localStorage.getItem(`grupos_${currentUser}`)) || [];
    const grupo = grupos[index];
    document.getElementById('nomeGrupo').value = grupo.nome;
    xogadoresGrupo = grupo.xogadores;
    grupoEditando = index;
    mostrarXogadoresGrupo();
}

function eliminarGrupo(index) {
    let grupos = JSON.parse(localStorage.getItem(`grupos_${currentUser}`)) || [];
    grupos.splice(index, 1);
    localStorage.setItem(`grupos_${currentUser}`, JSON.stringify(grupos));
    mostrarGrupos();
    actualizarSeleccionGrupos(); // Actualizar a selección de grupos
}

function mostrarXogadoresGrupo() {
    const listaXogadores = document.getElementById('listaXogadores');
    listaXogadores.innerHTML = '';
    xogadoresGrupo.forEach((xogador, index) => {
        const li = document.createElement('li');
        li.textContent = xogador;
        const eliminarBoton = document.createElement('button');
        eliminarBoton.textContent = "Eliminar";
        eliminarBoton.onclick = () => eliminarXogador(index);
        li.appendChild(eliminarBoton);
        listaXogadores.appendChild(li);
    });
}

function sair() {
    window.close();
}
